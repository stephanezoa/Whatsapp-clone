# Animated-LoginScreenApp

Animated-LoginScreen using [Kivy](https://github.com/kivy/kivy) and [KivyMD](https://github.com/kivymd/KivyMD)