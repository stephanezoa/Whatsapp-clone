from kivy.uix.boxlayout import BoxLayout

from components.adaptive_widget import AdaptiveWidget


class PBoxLayout(AdaptiveWidget, BoxLayout):
    pass
