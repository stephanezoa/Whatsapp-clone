from kivy.uix.screenmanager import Screen

from core.theming import ThemableBehavior


class PScreen(ThemableBehavior, Screen):
    pass
