# Example Kivy Apps

Some simple Apps built using [Kivy](https://github.com/kivy/kivy) and [KivyMD](https://github.com/kivymd/KivyMD)
